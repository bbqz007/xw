export ANDROID_ROOT=$ANDROID_NDK
# when arm arch, ${HOST}-${version}
# when x86 arch, ${ARCH}-${version}
# one of blow:
# aarch64-linux-android-4.9/  
# mipsel-linux-android-4.9/	mips
# arm-linux-androideabi-4.9/  	arm
# x86-4.9/			i686
# llvm/                       
# x86_64-4.9/			x86_64
# mips64el-linux-android-4.9/ 	mips64
export ANDROID_TOOLCHAIN_NAME=x86_64-4.9
export PATH=$PATH:$ANDROID_ROOT/toolchains/${ANDROID_TOOLCHAIN_NAME}/prebuilt/darwin-x86_64/bin
export ARCH=x86_64

# android ndk platform
# android-9
# android-1x
# android-2x
export ANDROID_NDK_PLATFORM=android-23
export ANDROID_HOST=x86_64-linux-android

# use lib64 instead, while arch is x86_64
# and android-21's lib64/* are incompatable.
# you don't have acknowlage of these, you may got a error like, -lc not found 
#  (CC can not find libc.so in path lib, but you should specify lib/lib instead.)
 ./configure \
 --host=${ANDROID_HOST}\
 CC=${ANDROID_HOST}-gcc \
 LD=${ANDROID_HOST}-ld \
 CPPFLAGS="-I$ANDROID_ROOT/platforms/${ANDROID_NDK_PLATFORM}/arch-${ARCH}/usr/include/" \
 CFLAGS="-nostdlib" \
 LDFLAGS="-Wl,-rpath-link=$ANDROID_ROOT/platforms/${ANDROID_NDK_PLATFORM}/arch-${ARCH}/usr/lib64 -L$ANDROID_ROOT/platforms/${ANDROID_NDK_PLATFORM}/arch-${ARCH}/usr/lib64" \
 LIBS="-lc -lgcc -L$ANDROID_ROOT/toolchains/${ANDROID_TOOLCHAIN_NAME}/prebuilt/darwin-x86_64/lib/gcc/${ANDROID_HOST}/4.9"

ln -s $ANDROID_ROOT/platforms/${ANDROID_NDK_PLATFORM}/arch-${ARCH}/usr/lib64/crtbegin_so.o
ln -s $ANDROID_ROOT/platforms/${ANDROID_NDK_PLATFORM}/arch-${ARCH}/usr/lib64/crtend_so.o

make
