#!/bin/bash
export ANDROID_NDK=~/Library/android-sdk/ndk-bundle
export ANDROID_SDK=~/Library/android-sdk
export ANDROID_PLATFORM=android-9
# toolchain path: ${ANDROID_NDK}/toolchains
export ANDROID_TOOLCHAIN_NAME=arm-linux-androideabi-4.9
echo ${ANDROID_NDK}
echo ${ANDROID_SDK}

# configue file use libtool (lt)
lt_AR=
lt_CC=
lt_LD=
lt_NM=
lt_OBJDUMP=
lt_RNDLIB=
lt_STRIP=
